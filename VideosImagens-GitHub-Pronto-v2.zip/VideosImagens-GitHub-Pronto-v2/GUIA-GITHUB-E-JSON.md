# Vídeos+imagens — Guia rápido

## 1. Coloque o catálogo no GitHub

Crie um repositório, por exemplo:

`videos-imagens`

Na raiz do repositório, coloque um arquivo chamado:

`catalog.json`

Exemplo:

```json
{
  "videos": [
    {
      "id": "video001",
      "title": "Meu vídeo",
      "url": "https://exemplo.com/video.mp4",
      "thumbnail": "https://exemplo.com/capa.jpg",
      "description": "Descrição opcional",
      "mimeType": "video/mp4"
    }
  ],
  "images": [
    {
      "id": "imagem001",
      "title": "Minha imagem",
      "url": "https://exemplo.com/imagem.jpg",
      "thumbnail": "https://exemplo.com/miniatura.jpg",
      "description": "Descrição opcional",
      "mimeType": "image/jpeg"
    }
  ]
}
```

## 2. Link que deve ser colocado no app

Se seu usuário do GitHub for `SEU_USUARIO` e o repositório for `videos-imagens`, use:

`https://raw.githubusercontent.com/SEU_USUARIO/videos-imagens/main/catalog.json`

No app:

**Configurações → Catálogo do GitHub → cole o link → Salvar e atualizar**

O app tenta primeiro o catálogo remoto. Se ele não estiver configurado ou houver erro de rede, usa o `catalog.json` de exemplo que está dentro do APK.

## 3. Como adicionar vídeos

Dentro de `"videos"`, acrescente outro objeto separado por vírgula:

```json
{
  "id": "video002",
  "title": "Segundo vídeo",
  "url": "https://exemplo.com/video2.mp4",
  "thumbnail": "https://exemplo.com/capa2.jpg",
  "mimeType": "video/mp4"
}
```

A propriedade `url` precisa apontar para o arquivo de mídia que o aparelho consiga acessar. Para HLS, pode ser uma URL `.m3u8` e `mimeType` pode ser `application/x-mpegURL`.

## 4. Como adicionar imagens

```json
{
  "id": "imagem002",
  "title": "Segunda imagem",
  "url": "https://exemplo.com/foto2.jpg",
  "thumbnail": "https://exemplo.com/thumb2.jpg",
  "mimeType": "image/jpeg"
}
```

## 5. Regras importantes do JSON

- Cada item deve ter um `id` diferente.
- `title` é o nome exibido no card.
- `url` é o endereço do conteúdo.
- `thumbnail` é opcional; se não existir, o app tenta usar a própria `url`.
- `description` é opcional.
- `mimeType` é recomendado.
- Não deixe vírgula depois do último item de uma lista JSON.
- Use aspas duplas nos nomes e valores.
- Prefira URLs HTTPS.

## 6. Abrir no Android Studio

1. Baixe e extraia este ZIP.
2. Abra o Android Studio.
3. Escolha **Open**.
4. Selecione a pasta `VideosImagens-GitHub-Pronto`.
5. Aguarde a sincronização do Gradle e o download das dependências.
6. Execute em um celular ou emulador.

O projeto usa Kotlin + Jetpack Compose + Media3/ExoPlayer.

## 7. Gerar APK pelo GitHub

O arquivo `.github/workflows/build-apk.yml` está preparado para o GitHub Actions.

Depois de enviar o projeto para o GitHub:

**Actions → Build APK → Run workflow**

O workflow compila o APK de debug e publica o APK como artefato da execução.

## 8. TV / Chromecast

O botão de transmitir usa o Google Cast. Celular e dispositivo receptor devem estar na mesma rede e a TV precisa conseguir acessar diretamente a URL do conteúdo.

## 9. Downloads

O botão de download usa o DownloadManager do Android e salva o conteúdo na área de Downloads. Baixe apenas conteúdos que você tenha autorização para armazenar.

## 10. Observação sobre hospedagem

O GitHub é usado neste projeto como repositório do código e do `catalog.json`. Para vídeos grandes, é melhor hospedar os arquivos de mídia em um serviço apropriado e colocar no JSON os links diretos para esses arquivos.


## Compilação GitHub (versão atualizada)
Este projeto usa AGP 9.1.1, Gradle 9.3.1, Kotlin 2.2.10 e compileSdk 37 para compatibilidade com Android API 37. O workflow do GitHub instala a plataforma Android 37 antes da compilação.
