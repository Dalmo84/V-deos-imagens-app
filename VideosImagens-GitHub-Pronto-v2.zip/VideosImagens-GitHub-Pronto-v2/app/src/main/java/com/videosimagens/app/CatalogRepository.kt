package com.videosimagens.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object CatalogRepository {
    private const val PREFS = "catalog_settings"
    private const val KEY_URL = "catalog_url"
    const val DEFAULT_URL = ""

    fun getUrl(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_URL, DEFAULT_URL) ?: DEFAULT_URL

    fun setUrl(context: Context, url: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_URL, url.trim())
            .apply()
    }

    fun loadFromAssets(context: Context): Catalog {
        val json = context.assets.open("catalog.json").bufferedReader().use { it.readText() }
        return parse(json)
    }

    fun loadRemote(context: Context): Catalog {
        val catalogUrl = getUrl(context)
        require(catalogUrl.isNotBlank()) { "Catálogo remoto ainda não configurado." }
        val connection = URL(catalogUrl).openConnection() as HttpURLConnection
        connection.connectTimeout = 10000
        connection.readTimeout = 15000
        connection.requestMethod = "GET"
        connection.connect()
        if (connection.responseCode !in 200..299) {
            throw IllegalStateException("HTTP ${connection.responseCode}")
        }
        return connection.inputStream.bufferedReader().use { parse(it.readText()) }
    }

    fun parse(jsonText: String): Catalog {
        val root = JSONObject(jsonText)
        val videos = mutableListOf<MediaItem>()
        val images = mutableListOf<MediaItem>()

        val videosArray = root.optJSONArray("videos")
        if (videosArray != null) {
            for (i in 0 until videosArray.length()) {
                videos += videosArray.getJSONObject(i).toMediaItem(MediaType.VIDEO)
            }
        }

        val imagesArray = root.optJSONArray("images")
        if (imagesArray != null) {
            for (i in 0 until imagesArray.length()) {
                images += imagesArray.getJSONObject(i).toMediaItem(MediaType.IMAGE)
            }
        }

        return Catalog(videos, images)
    }
}
