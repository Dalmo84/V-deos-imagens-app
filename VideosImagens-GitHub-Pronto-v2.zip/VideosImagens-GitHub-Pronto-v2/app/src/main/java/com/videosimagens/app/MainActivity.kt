package com.videosimagens.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.media.RemoteMediaClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VideosImagensApp() }
    }

    fun castMedia(item: MediaItem) {
        val session: CastSession? =
            CastContext.getSharedInstance(this).sessionManager.currentCastSession
        val client: RemoteMediaClient = session?.remoteMediaClient ?: run {
            Toast.makeText(this, "Conecte primeiro a uma TV pelo botão de transmitir.", Toast.LENGTH_SHORT).show()
            return
        }

        val mime = item.mimeType ?: if (item.type == MediaType.IMAGE) guessImageMime(item.url) else guessVideoMime(item.url)
        val metadata = MediaMetadata(MediaMetadata.MEDIA_TYPE_GENERIC).apply {
            putString(MediaMetadata.KEY_TITLE, item.title)
            item.description?.let { putString(MediaMetadata.KEY_SUBTITLE, it) }
        }
        val info = MediaInfo.Builder(item.url)
            .setContentType(mime)
            .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
            .setMetadata(metadata)
            .build()

        client.load(
            MediaLoadRequestData.Builder()
                .setMediaInfo(info)
                .build()
        )
    }

    private fun guessImageMime(url: String): String {
        return when {
            url.lowercase(Locale.US).contains(".png") -> "image/png"
            url.lowercase(Locale.US).contains(".webp") -> "image/webp"
            else -> "image/jpeg"
        }
    }

    private fun guessVideoMime(url: String): String {
        val lower = url.lowercase(Locale.US)
        return when {
            lower.contains(".m3u8") -> "application/x-mpegURL"
            lower.contains(".webm") -> "video/webm"
            else -> "video/mp4"
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@androidx.compose.runtime.Composable
fun VideosImagensApp() {
    val context = LocalContext.current
    var catalog by remember { mutableStateOf(Catalog(emptyList(), emptyList())) }
    var loading by remember { mutableStateOf(true) }
    var selected by remember { mutableStateOf<MediaItem?>(null) }
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }
    var favorites by remember { mutableStateOf(loadFavorites(context)) }
    var showSettings by remember { mutableStateOf(false) }
    var catalogUrl by remember { mutableStateOf(CatalogRepository.getUrl(context)) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    suspend fun refresh() {
        loading = true
        catalog = try {
            withContext(Dispatchers.IO) { CatalogRepository.loadRemote(context) }
        } catch (_: Exception) {
            CatalogRepository.loadFromAssets(context)
        }
        loading = false
    }

    LaunchedEffect(Unit) { refresh() }

    MaterialTheme(colorScheme = darkColorScheme()) {
        if (selected != null) {
            MediaViewer(
                item = selected!!,
                catalog = catalog,
                onBack = { selected = null },
                onSelect = { selected = it },
                onDownload = { downloadMedia(context, it) },
                isFavorite = favorites.contains(selected!!.id),
                onFavorite = {
                    favorites = toggleFavorite(context, selected!!.id)
                }
            )
            return@MaterialTheme
        }

        val source = when (tab) {
            0 -> catalog.videos
            1 -> catalog.images
            else -> catalog.all.filter { favorites.contains(it.id) }
        }
        val filtered = source.filter {
            query.isBlank() || it.title.contains(query, ignoreCase = true)
        }

        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text("Vídeos+imagens", fontWeight = FontWeight.Bold) },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = Color(0xFF050A18)
                    ),
                    actions = {
                        IconButton(onClick = { /* pesquisa já aparece abaixo */ }) {
                            Icon(Icons.Default.Search, contentDescription = "Pesquisar")
                        }
                        IconButton(onClick = { scope.launch { refresh() } }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Atualizar")
                        }
                        CastButton()
                        IconButton(onClick = { showSettings = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Configurações")
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar(modifier = Modifier.navigationBarsPadding()) {
                    NavigationBarItem(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.VideoLibrary, null) },
                        label = { Text("Vídeos") }
                    )
                    NavigationBarItem(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.Image, null) },
                        label = { Text("Imagens") }
                    )
                    NavigationBarItem(
                        selected = tab == 2,
                        onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.Favorite, null) },
                        label = { Text("Favoritos") }
                    )
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Color(0xFF050A18))
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    singleLine = true,
                    label = { Text("Pesquisar") }
                )

                if (loading) {
                    Text("Carregando catálogo…", modifier = Modifier.padding(16.dp))
                } else if (filtered.isEmpty()) {
                    Text(
                        "Nenhum conteúdo encontrado.",
                        modifier = Modifier.padding(16.dp)
                    )
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 160.dp),
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filtered, key = { it.id }) { item ->
                            MediaCard(
                                item = item,
                                isFavorite = favorites.contains(item.id),
                                onClick = { selected = item },
                                onFavorite = {
                                    favorites = toggleFavorite(context, item.id)
                                },
                                onDownload = { downloadMedia(context, item) }
                            )
                        }
                    }
                }
            }
        }

        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("Catálogo do GitHub") },
                text = {
                    Column {
                        Text("Cole aqui o link RAW do seu catalog.json:")
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = catalogUrl,
                            onValueChange = { catalogUrl = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            placeholder = {
                                Text("https://raw.githubusercontent.com/usuario/repo/main/catalog.json")
                            }
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        CatalogRepository.setUrl(context, catalogUrl)
                        showSettings = false
                        scope.launch { refresh() }
                    }) {
                        Text("Salvar e atualizar")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showSettings = false }) {
                        Text("Cancelar")
                    }
                }
            )
        }
    }
}

@Composable
fun CastButton() {
    val context = LocalContext.current
    AndroidView(
        factory = { ctx ->
            androidx.mediarouter.app.MediaRouteButton(ctx).also { button ->
                CastButtonFactory.setUpMediaRouteButton(ctx, button)
            }
        },
        modifier = Modifier.size(48.dp)
    )
}

@Composable
fun MediaCard(
    item: MediaItem,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onFavorite: () -> Unit,
    onDownload: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 10f)
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .background(Color(0xFF18233B)),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = item.thumbnail ?: item.url,
                    contentDescription = item.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Surface(
                    modifier = Modifier.align(Alignment.TopStart).padding(8.dp),
                    color = Color.Black.copy(alpha = .65f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        if (item.type == MediaType.VIDEO) "VÍDEO" else "IMAGEM",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Text(
                item.title,
                modifier = Modifier.padding(start = 12.dp, top = 10.dp, end = 12.dp),
                maxLines = 2,
                fontWeight = FontWeight.SemiBold
            )

            Row(
                modifier = Modifier.fillMaxWidth().padding(4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(onClick = onFavorite) {
                    Icon(
                        if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorito"
                    )
                }
                IconButton(onClick = onDownload) {
                    Icon(Icons.Default.Download, contentDescription = "Baixar")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaViewer(
    item: MediaItem,
    catalog: Catalog,
    onBack: () -> Unit,
    onSelect: (MediaItem) -> Unit,
    onDownload: () -> Unit,
    isFavorite: Boolean,
    onFavorite: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? MainActivity
    val list = if (item.type == MediaType.VIDEO) catalog.videos else catalog.images
    val index = list.indexOfFirst { it.id == item.id }
    val previous = list.getOrNull(index - 1)
    val next = list.getOrNull(index + 1)

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(item.title, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "Voltar")
                    }
                },
                actions = {
                    IconButton(onClick = onFavorite) {
                        Icon(
                            if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            "Favorito"
                        )
                    }
                    IconButton(onClick = onDownload) {
                        Icon(Icons.Default.Download, "Baixar")
                    }
                    CastButton()
                }
            )
        },
        containerColor = Color.Black
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color.Black),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (item.type == MediaType.VIDEO) {
                VideoPlayer(item)
            } else {
                AsyncImage(
                    model = item.url,
                    contentDescription = item.title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(8.dp),
                    contentScale = ContentScale.Fit
                )
            }

            if (!item.description.isNullOrBlank()) {
                Text(
                    item.description!!,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    color = Color.LightGray
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(
                    onClick = { previous?.let(onSelect) },
                    enabled = previous != null
                ) {
                    Icon(Icons.Default.SkipPrevious, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Anterior")
                }
                Button(
                    onClick = { activity?.castMedia(item) }
                ) {
                    Icon(Icons.Default.Cast, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Transmitir")
                }
                Button(
                    onClick = { next?.let(onSelect) },
                    enabled = next != null
                ) {
                    Text("Próximo")
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.Default.SkipNext, null)
                }
            }
        }
    }
}

@Composable
fun VideoPlayer(item: MediaItem) {
    val context = LocalContext.current
    val player = remember(item.url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(ExoMediaItem.fromUri(item.url))
            prepare()
            playWhenReady = true
        }
    }

    androidx.compose.runtime.DisposableEffect(player) {
        onDispose { player.release() }
    }

    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                this.player = player
                useController = true
                controllerShowTimeoutMs = 2500
            }
        },
        modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
    )
}

fun downloadMedia(context: Context, item: MediaItem) {
    try {
        val request = DownloadManager.Request(Uri.parse(item.url))
            .setTitle(item.title)
            .setDescription("Vídeos+imagens")
            .setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            )
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)

        val extension = when {
            item.url.lowercase(Locale.US).contains(".png") -> ".png"
            item.url.lowercase(Locale.US).contains(".webp") -> ".webp"
            item.url.lowercase(Locale.US).contains(".jpg") ||
                item.url.lowercase(Locale.US).contains(".jpeg") -> ".jpg"
            item.url.lowercase(Locale.US).contains(".webm") -> ".webm"
            else -> ".mp4"
        }

        request.setDestinationInExternalPublicDir(
            Environment.DIRECTORY_DOWNLOADS,
            "Videos+imagens/${sanitize(item.title)}$extension"
        )

        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        manager.enqueue(request)
        Toast.makeText(context, "Download iniciado.", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(context, "Não foi possível iniciar o download.", Toast.LENGTH_LONG).show()
    }
}

fun sanitize(value: String): String =
    value.replace(Regex("""[\\/:*?"<>|]"""), "_").take(80)

fun loadFavorites(context: Context): Set<String> =
    context.getSharedPreferences("favorites", Context.MODE_PRIVATE)
        .getStringSet("ids", emptySet()) ?: emptySet()

fun toggleFavorite(context: Context, id: String): Set<String> {
    val prefs = context.getSharedPreferences("favorites", Context.MODE_PRIVATE)
    val current = prefs.getStringSet("ids", emptySet())?.toMutableSet() ?: mutableSetOf()
    if (!current.add(id)) current.remove(id)
    prefs.edit().putStringSet("ids", current).apply()
    return current
}
