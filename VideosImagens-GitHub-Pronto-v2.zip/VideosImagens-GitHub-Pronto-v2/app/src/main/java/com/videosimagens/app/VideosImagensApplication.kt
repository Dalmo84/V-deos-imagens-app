package com.videosimagens.app

import android.app.Application
import com.google.android.gms.cast.framework.CastContext

class VideosImagensApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        CastContext.getSharedInstance(this)
    }
}
