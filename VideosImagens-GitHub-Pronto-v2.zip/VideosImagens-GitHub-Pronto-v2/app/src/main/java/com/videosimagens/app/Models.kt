package com.videosimagens.app

import org.json.JSONObject

enum class MediaType { VIDEO, IMAGE }

data class MediaItem(
    val id: String,
    val title: String,
    val url: String,
    val type: MediaType,
    val thumbnail: String? = null,
    val description: String? = null,
    val mimeType: String? = null
)

data class Catalog(
    val videos: List<MediaItem>,
    val images: List<MediaItem>
) {
    val all: List<MediaItem> get() = videos + images
}

fun JSONObject.toMediaItem(type: MediaType): MediaItem {
    return MediaItem(
        id = optString("id").ifBlank { System.currentTimeMillis().toString() },
        title = optString("title").ifBlank { "Sem título" },
        url = optString("url"),
        type = type,
        thumbnail = optString("thumbnail").takeIf { it.isNotBlank() },
        description = optString("description").takeIf { it.isNotBlank() },
        mimeType = optString("mimeType").takeIf { it.isNotBlank() }
    )
}
