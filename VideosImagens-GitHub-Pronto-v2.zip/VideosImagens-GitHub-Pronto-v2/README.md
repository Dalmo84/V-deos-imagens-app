# Vídeos+imagens

Aplicativo Android pessoal para organizar e reproduzir vídeos e imagens a partir de um catálogo JSON hospedado no GitHub.

## O que já vem pronto

- Cards separados para vídeo e imagem.
- Pesquisa.
- Favoritos.
- Player Media3/ExoPlayer.
- Botão de transmitir via Google Cast/Chromecast.
- Próximo/anterior.
- Download para a pasta Downloads.
- Atualização do catálogo remoto.
- Catálogo local de reserva (`app/src/main/assets/catalog.json`).
- GitHub Actions para gerar o APK.

## 1. Criar seu repositório

Crie um repositório no GitHub, por exemplo:

`videos-imagens`

Envie todo o conteúdo desta pasta para ele.

## 2. Criar o catalog.json

Na raiz do repositório, crie:

`catalog.json`

Você pode copiar o arquivo de exemplo que está em `app/src/main/assets/catalog.json`.

### Estrutura

```json
{
  "videos": [
    {
      "id": "video001",
      "title": "Meu vídeo",
      "url": "https://site.com/meu-video.mp4",
      "thumbnail": "https://site.com/capa.jpg",
      "description": "Descrição opcional",
      "mimeType": "video/mp4"
    }
  ],
  "images": [
    {
      "id": "imagem001",
      "title": "Minha imagem",
      "url": "https://site.com/minha-imagem.jpg",
      "thumbnail": "https://site.com/minha-miniatura.jpg",
      "description": "Descrição opcional",
      "mimeType": "image/jpeg"
    }
  ]
}
```

## 3. Como adicionar outro vídeo

Dentro de `videos`, coloque outro objeto separado por vírgula:

```json
{
  "id": "video002",
  "title": "Outro vídeo",
  "url": "https://exemplo.com/outro.mp4",
  "thumbnail": "https://exemplo.com/capa.jpg",
  "mimeType": "video/mp4"
}
```

## 4. Como adicionar uma imagem

Dentro de `images`:

```json
{
  "id": "imagem002",
  "title": "Outra imagem",
  "url": "https://exemplo.com/foto.jpg",
  "thumbnail": "https://exemplo.com/miniatura.jpg",
  "mimeType": "image/jpeg"
}
```

## 5. Tipos de arquivo

Vídeo:
- MP4: `video/mp4`
- WebM: `video/webm`
- HLS/M3U8: `application/x-mpegURL`

Imagem:
- JPG/JPEG: `image/jpeg`
- PNG: `image/png`
- WebP: `image/webp`

## 6. Configurar o link do GitHub no próprio aplicativo

Você **não precisa editar o código para trocar o catálogo**.

Depois de instalar o app:

1. Abra o aplicativo.
2. Toque no ícone ⚙️ de configurações.
3. Cole o link RAW do seu `catalog.json`.
4. Toque em **Salvar e atualizar**.

Exemplo:

```text
https://raw.githubusercontent.com/joao/videos-imagens/main/catalog.json
```

Se sua branch se chamar `master`, troque `main` por `master`.

O endereço fica salvo no celular. Depois, sempre que você alterar o `catalog.json` no GitHub, basta tocar em **Atualizar** dentro do app.

## 7. Muito importante sobre os links

Os links de `url` e `thumbnail` precisam ser acessíveis pelo aplicativo.

Para vídeo, use o link direto do arquivo, e não uma página HTML.

Bom:

`https://meusite.com/videos/video.mp4`

Ruim:

`https://meusite.com/pagina-do-video`

Para imagens vale a mesma regra.

## 8. Compilar no Android Studio

1. Instale o Android Studio.
2. Abra a pasta `VideosImagens`.
3. Aguarde o Gradle sincronizar.
4. Conecte seu celular Android com Depuração USB ou use um emulador.
5. Pressione Run ▶.

O projeto usa versões atuais de AndroidX/Media3 e Google Cast. O Android Studio pode baixar as dependências automaticamente na primeira sincronização.

## 9. Gerar APK pelo GitHub

O projeto possui:

`.github/workflows/build-apk.yml`

Depois de enviar o projeto para o GitHub:

1. Abra a aba **Actions**.
2. Entre em **Build APK**.
3. Execute o workflow.
4. O APK aparecerá como artefato da execução.

Também é possível configurar uma Release posteriormente.

## 10. Atualizar conteúdo sem recompilar o aplicativo

Depois de instalado:

1. Edite somente `catalog.json`.
2. Faça commit no GitHub.
3. Abra o aplicativo.
4. Toque em atualizar.

O aplicativo tentará buscar o catálogo remoto. Se estiver sem internet ou o endereço estiver incorreto, ele usa o catálogo de reserva que veio dentro do APK.

## Observações

- O GitHub hospeda o catálogo; não é recomendado usar o GitHub como servidor de streaming para uma grande biblioteca de vídeos.
- Use somente mídia que você tenha autorização para reproduzir/baixar.
- Para Chromecast/Google Cast, o dispositivo e o celular precisam estar na rede compatível e o conteúdo precisa ser acessível pela TV.
- O botão de transmitir usa o receptor de mídia padrão do Google Cast, portanto não é necessário criar um servidor próprio para a primeira versão.


## Guia de GitHub e JSON

Consulte `GUIA-GITHUB-E-JSON.md` para configurar o catálogo e adicionar vídeos/imagens.
